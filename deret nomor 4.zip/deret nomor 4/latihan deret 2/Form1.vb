﻿Public Class Form1

    Private Sub Button1_Click(sender As System.Object, e As System.EventArgs) Handles Button1.Click
        Dim n, i, j, k, l, m, x, y, z, w As Integer
        Dim wrap As String

        wrap = Chr(13) & Chr(10)

        For n = 0 To 20
            If n = 0 Then
                i = n + 8
            ElseIf n = 8 Then
                j = n + 2
            ElseIf n = 10 Then
                k = n + 2
            End If
        Next n
        For x = 0 To 20
            If x = 0 Then
                w = x + 12
            ElseIf x = 12 Then
                y = x + 3
            ElseIf x = 15 Then
                z = x + 3
            End If
        Next x
        TextBox1.Text = i & wrap & w & wrap & j & wrap & y & wrap & k & wrap & z & wrap
    End Sub
End Class
