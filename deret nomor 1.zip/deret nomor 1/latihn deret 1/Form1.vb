﻿Public Class Form1

    Private Sub Button1_Click(sender As System.Object, e As System.EventArgs) Handles Button1.Click
        Dim n, i, j, k, l, m, x, y, z, w As Integer
        Dim wrap As String

        wrap = Chr(13) & Chr(10)

        For n = 0 To 20
            If n = 0 Then
                i = n + 2
            ElseIf n = 2 Then
                j = n + 6
            ElseIf n = 8 Then
                k = n + 6
            ElseIf n = 14 Then
                l = n + 6
            End If
        Next n
        For x = 0 To 25
            If x = 0 Then
                w = x + 4
            ElseIf x = 4 Then
                y = x + 10
            ElseIf x = 14 Then
                z = x + 10
            End If
        Next x
        TextBox1.Text = i & wrap & w & wrap & j & wrap & y & wrap & k & wrap & z & wrap & l & wrap
    End Sub
End Class
