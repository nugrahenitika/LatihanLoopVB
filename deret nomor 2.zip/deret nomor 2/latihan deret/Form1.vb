﻿Public Class Form1

    Private Sub Button1_Click(sender As System.Object, e As System.EventArgs) Handles Button1.Click
        Dim n, i, j, k, l, m, x, y, z, w As Integer
        Dim wrap As String

        wrap = Chr(13) & Chr(10)

        For n = 1 To 21
            If n = 1 Then
                i = 1 * 3
            ElseIf n = 3 Then
                j = n * 3
            ElseIf n = 5 Then
                k = n * 3
            ElseIf n = 7 Then
                l = n * 3
            End If
        Next n
        For x = 1 To 25
            If x = 1 Then
                w = x * 5
            ElseIf x = 3 Then
                y = x * 5
            ElseIf x = 5 Then
                z = x * 5
            End If
        Next x
        TextBox1.Text = i & wrap & w & wrap & j & wrap & y & wrap & k & wrap & z & wrap & l & wrap
    End Sub
End Class
